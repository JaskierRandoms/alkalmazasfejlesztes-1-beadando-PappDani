﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;

namespace PappDaniPhoneBook
{
    /// <summary>
    /// Interaction logic for Delete.xaml
    /// </summary>
    public partial class Delete : Window
    {
        public Delete()
        {
            InitializeComponent();
            Connect();

            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id FROM contacts", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            IDs.ItemsSource = ds.Tables[0].DefaultView;
            IDs.DisplayMemberPath = ds.Tables[0].Columns["id"].ToString();
            IDs.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
        }
        private static MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=phonebook");
        private static void Connect()
        {
            try
            {
                conn.Open();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
        private void IDs_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {

        }

        private void IDs_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            int id = Convert.ToInt32(IDs.SelectedValue);
            string sql = "SELECT id, CONCAT_WS(' ', name, number, type) as ossz FROM contacts WHERE id = " + id;
            
            // sql = string.Format("SELECT id, CONCAT_WS(' ', name, number, type) as ossz FROM contacts WHERE id = {0}", id);
           // MessageBox.Show(sql);
            MySqlDataAdapter da = new MySqlDataAdapter(sql, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            lb.ItemsSource = ds.Tables[0].DefaultView;
            lb.DisplayMemberPath = ds.Tables[0].Columns["ossz"].ToString();
            lb.SelectedValuePath = ds.Tables[0].Columns[0].ToString();
            

        }

        private void IDs_SourceUpdated(object sender, DataTransferEventArgs e)
        {
          
        }

        private void IDs_TargetUpdated(object sender, DataTransferEventArgs e)
        {
          
        }

        private void DeleteData_Click(object sender, RoutedEventArgs e)
        {
            if(IDs.Text == "")
            {
                MessageBox.Show("Kérem válasszon egy ID-t a törléshez");
            }
            string id = IDs.Text;
            string sql;
            MySqlCommand cmd;
            sql = String.Format("DELETE FROM contacts WHERE id = {0}", id);
            cmd = new MySqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            string endmsg = "A(z) "+ id +" ID vel rendelkező ügyfelet töröltük.";
            MessageBox.Show(endmsg);
            conn.Close();
            this.Close();
        }
    }
}
