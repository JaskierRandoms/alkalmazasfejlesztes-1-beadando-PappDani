﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PappDaniPhoneBook
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
            Connectioncs.ListBoxFillShort(lb);            
        }

        private void view_Click(object sender, RoutedEventArgs e)
        {
            if (view.Content.ToString() == "Részletes nézet")
            {
                Connectioncs.ListBoxFillLong(lb);
                view.Content = "Minimalista nézet";
            }
            else if(view.Content.ToString() == "Minimalista nézet")
            {
                Connectioncs.ListBoxFillShort(lb);
                view.Content = "Részletes nézet";
            }
        }

        private void createNew_Click(object sender, RoutedEventArgs e)
        {
            NewContact popup = new NewContact();
            popup.Show();
        }

        private void edit_Click(object sender, RoutedEventArgs e)
        {
            update upd = new update();
            upd.Show();
        }

        private void delet_Click(object sender, RoutedEventArgs e)
        {
            Delete del = new Delete();
            del.Show();
        }
    }
}
