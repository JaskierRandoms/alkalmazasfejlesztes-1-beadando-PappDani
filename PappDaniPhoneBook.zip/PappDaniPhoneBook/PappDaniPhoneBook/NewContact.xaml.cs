﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;


namespace PappDaniPhoneBook
{
    /// <summary>
    /// Interaction logic for NewContact.xaml
    /// </summary>
    public partial class NewContact : Window
    {
        public NewContact()
        {
            InitializeComponent();
            Connect();
        }

        private static MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=phonebook");
        private static void Connect()
        {
            try
            {
                conn.Open();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void create_Click(object sender, RoutedEventArgs e)
        {            
            string newname = name.Text;
            string newnumber = number.Text;
            string newtypo = typo.Text;
            if (newname == "" || newnumber == "" || newtypo == "")
            {
                MessageBox.Show("Kérem minden mezőt töltsön ki");
                return;
            }

            if (Hulyebiztositas.Namecheck(name.Text))
                newname = name.Text;
            else
            {
                MessageBox.Show("Kérem adjon meg egy RENDES nevet!");
                return;
            }
            
            

            string sql;
            MySqlCommand cmd;
            sql = String.Format("INSERT INTO contacts(id, name, number, type) VALUES(NULL, '{0}', '{1}','{2}')", newname, newnumber, newtypo);
            cmd = new MySqlCommand(sql, conn);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Új felhasználó hozzá adva.");            
            conn.Close();
            this.Close();
        }
    }
}
