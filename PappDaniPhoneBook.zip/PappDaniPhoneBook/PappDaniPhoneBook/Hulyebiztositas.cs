﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PappDaniPhoneBook
{
    class Hulyebiztositas
    {
        public static bool Namecheck(string name)
        {
            char[] nagyekezet = new char[] { 'Ö', 'Ü', 'Ó', 'Ú', 'Ő', 'Ű', 'Á', 'É', 'Í' };
            char[] kisekezet = new char[] { 'ö', 'ü', 'ó', 'ú', 'ő', 'ű', 'á', 'é', 'í' };
            bool bigcheck = false;
            bool kischeck = false;

            if (!((int)name[0] >= 65 && (int)name[0] <= 90))
            {
                for (int i = 0; i < nagyekezet.Length && !bigcheck; i++)
                {
                    if (name[0] == nagyekezet[i])
                    {
                        bigcheck = true;                        
                    }

                    if (i == nagyekezet[i])
                        return false;
                }
            }
            else
                bigcheck = true;

            if (bigcheck)
            {
                for (int i = 1; i < name.Length; i++)
                {
                    for (int j = 0; j < kisekezet.Length && !kischeck; j++)
                    {
                        if (name[i] == kisekezet[j])
                        {
                            kischeck = true;
                        }
                        if (j == kisekezet.Length && !kischeck)
                        {
                            kischeck = false;
                            return false;
                        }                          
                    }

                    if (!kischeck && (int)name[i] >= 97 && (int)name[i] <= 122)                    
                        return true;                    
                    else
                        return false;
                }
            }
            else
                return false;

            return false;
        }

      

    }
}
