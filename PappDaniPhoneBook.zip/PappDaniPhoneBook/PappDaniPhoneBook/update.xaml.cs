﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;

namespace PappDaniPhoneBook
{
    /// <summary>
    /// Interaction logic for update.xaml
    /// </summary>
    public partial class update : Window
    {
        private static MySqlConnection conn = new MySqlConnection("SERVER=localhost;UID=root;PWD=;DATABASE=phonebook");
        private static void Connect()
        {
            try
            {
                conn.Open();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
        public update()
        {
            InitializeComponent();
            Connect();

            MySqlDataAdapter da = new MySqlDataAdapter("SELECT id FROM contacts", conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            IDs.ItemsSource = ds.Tables[0].DefaultView;
            IDs.DisplayMemberPath = ds.Tables[0].Columns["id"].ToString();
            IDs.SelectedValuePath = ds.Tables[0].Columns[0].ToString();

        }

        private void updatedata_Click(object sender, RoutedEventArgs e)
        {
            string newname = name.Text;
            string newnumber = number.Text;
            string newtypo = typo.Text;


            if (newname == "" || newnumber == "" || newtypo == "" || IDs.Text == "")
            {
                MessageBox.Show("Kérem minden mezőt töltsön ki");
                return;
            }

            if (Hulyebiztositas.Namecheck(name.Text))
                newname = name.Text;
            else
            {
                MessageBox.Show("Kérem adjon meg egy RENDES nevet!");
                return;
            }

            

            int id = Convert.ToInt32(IDs.Text);

            string sql;
            MySqlCommand cmd;
            sql = String.Format("UPDATE contacts SET name = '{0}', number = '{1}', type = '{2}' WHERE id = {3}", newname, newnumber, newtypo, id);
            cmd = new MySqlCommand(sql, conn);
            cmd.ExecuteNonQuery();

            MessageBox.Show("A felhasználó adatai módosultak.");
            conn.Close();
            this.Close();
        }

        private void Label_DragOver(object sender, DragEventArgs e)
        {

        }
    }
}
